package katachi.spring.exercise.form;

import lombok.Data;

@Data
public class ItemAddForm {

	private Integer id;

	private Integer cartItemInventory;
}
