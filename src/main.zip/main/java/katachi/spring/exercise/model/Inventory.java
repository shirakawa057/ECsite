package katachi.spring.exercise.model;

import lombok.Data;

@Data
public class Inventory {

	private Integer itemId;
	private Integer inventory;
}
